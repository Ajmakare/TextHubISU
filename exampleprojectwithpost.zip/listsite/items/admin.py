from django.contrib import admin
from .models import WorkoutEntry
# Register your models here.
admin.site.register(WorkoutEntry)
